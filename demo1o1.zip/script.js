function login() {const name = document.getElementById("name").value;const phone = document .getElementById("phone").value;
              if (name && phone)   {// save to local storge for later
              localstorage.setItem("userName",name);
              localstorage.setItem("userPhone",phone);
              document.getElementById("login").style.display = "none";
              document.getElementById("app").style.display = "block";} else {alert("please enter both your name  and phone number.")}
                 }
let selectedTemplate = ""; function selectTemplate(template)
{
  selectedTemplate = template; alert('selected template: ${template}');
}
function startDesign() {if (selectedTemplate) {// proceed to design costumization
  document.getElementById("templates").style.display = "none";
  showcustomizationOptions(0:}else{
  alert("please select a template first.");
}
                       }
function
  showCustomizaionOptions() {
    document.getElementById("customize").style.display = "block";
  }
function finishCustomization() {
  // Get customization options
  const color = document.getElementById("color"),value;
  const size = document.getElementById("size").value;
  const design = document.getElementById("designUpload").files[0];
  if (design) {
    alert("please upload a design");
    return;
  }
  // save details for the other email
  localstorage.setItem("color".color);
  localstorage.setItem("size",size);
  localstorage.setItem("designfileName",design.name);
  showOrderbutton();
}
function showOrderButton() {
  document.getElementById("orderButton").style.display = "block";
}
function placeOrder() {
  const userName = localstorage.getItem("username");
  const userPhone = localstorage.getItem("userPhone");
  const color = localstorage.getItem("color");
  const size = localstorage.getItem("size");
  const designFileName = localstorage.getItem("designFileName");
  const emailbody = '
    name: ${userName}\n
  phone:${userPhone}\n
  Template: ${selectedTemplate}\n
  color: ${color}\n
  size; ${size}\n
  Design File: ${designFileName}\n';
    window.open('mailto:Israviaprinting@gmail.com?subject=new order&body=${encodeURIComponent(emailbody)}');
}